# 演算法分析機測
# 學號: 10624370/10627130/10627131
# 姓名: 鄭淵哲/林冠良/李峻瑋
# 中原大學資訊工程系
# Preorder to Postorder Problem
# Build a binary tree from preorder transversal and output as postorder transversal

class Node(): 
	def __init__(self, data): 
		self.data = data 
		self.left = None
		self.right = None
		self.isChar = False

def constructTreeUtil(pre, low, high, size):
	if( constructTreeUtil.index >= size or low > high): 
		return None
	root = Node(pre[constructTreeUtil.index]) 
	constructTreeUtil.index += 1
	if low == high: 
		return root 
	for i in range(low, high+1): 
		if (pre[i] > root.data): 
			break
	root.left = constructTreeUtil(pre, constructTreeUtil.index, i-1 , size)
	root.right = constructTreeUtil(pre, i, high, size)
	return root 

def constructTree(pre): 
	size = len(pre)
	constructTreeUtil.index = 0
	return constructTreeUtil(pre, 0, size-1, size) 

def printPostorder(root, isChar):
	if root is None:
		return
	if isChar == False:
		printPostorder(root.left, False)
		printPostorder(root.right, False)
		print(root.data, end=' ')
	if isChar == True:
		printPostorder(root.left, True)
		printPostorder(root.right, True)
		print(chr(root.data), end=' ')
		
if __name__ == '__main__':
	answers = []
	nodeValue = list(input().split())
	while len(nodeValue) != 1:
		isChar = False
		preorder = []
		for values in nodeValue:
			if values.isnumeric():
				preorder.append(int(values))
			else:
				isChar = True
				preorder.append(ord(values))
		root = constructTree(preorder)
		root.isChar = isChar
		answers.append(root)
		nodeValue = list(input().split())
	for roots in answers:
		printPostorder(roots, roots.isChar)
		print("\r")