#coding=utf-8
# 演算法分析機測
# 學號: 10624370/10627130/10627131
# 姓名: 鄭淵哲/林冠良/李峻瑋
# 中原大學資訊工程系
# Grid Puzzle
# using BFS
import collections

class Solution():
    def slidingPuzzle(self, board):
        start = self.board2str(board)
        
        bfs = collections.deque()
        bfs.append((start, 0)) # start is string 
        visited = set()
        visited.add(start) # string
        steplist = []
        
        dirs = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        
        while bfs:
            path, step = bfs.popleft()

            if path[0] == "1" :
                steplist.append(step)

            p = path.index("0")
            x, y = int(p / 3), p % 3
            path = list(path)
            for dir in dirs:
                tx, ty = x + dir[0], y + dir[1]
                if tx < 0 or tx >= 3 or ty < 0 or ty >= 3:
                    continue
                #print(x, y, tx, ty)
                #print(int(x * 3 + y), int(tx * 3 + ty), int(tx * 3 + ty), int(x * 3 + y))
                path[int(x * 3 + y)], path[int(tx * 3 + ty)] = path[int(tx * 3 + ty)], path[int(x * 3 + y)]
                pathStr = "".join(path)
                if pathStr not in visited :
                    bfs.append((pathStr, step + int(path[int(x * 3 + y)])))
                    visited.add(pathStr)
                path[int(x * 3 + y)], path[int(tx * 3 + ty)] = path[int(tx * 3 + ty)], path[int(x * 3 + y)]
        return steplist
    
    def board2str(self, board):
        bstr = ""
        for i in range(3):
            for j in range(3):
                bstr += str(board[i][j])
        return bstr

def main() :
    obj1 = Solution()

    digits = []
    print("Please input your slide puzzle panel...")
    for i in range(3):
        #digit = input().split()
        digit = [int(i) for i in input().split()]
        digits.append(digit)

    digit_panel = [digits[0],digits[1],digits[2]]
    
    steplist = obj1.slidingPuzzle(digit_panel)
    answer = 10000
    for step in steplist :
        if step < answer : 
            answer = step
            
    print("Minimum Sum of Costs =", answer)

if __name__ == "__main__" :
    main()